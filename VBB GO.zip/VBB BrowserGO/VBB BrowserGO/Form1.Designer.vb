﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla mediante l'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Backward = New System.Windows.Forms.Button()
        Me.Forward = New System.Windows.Forms.Button()
        Me.Reload = New System.Windows.Forms.Button()
        Me.Search = New System.Windows.Forms.Button()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Backward
        '
        Me.Backward.Location = New System.Drawing.Point(12, 9)
        Me.Backward.Name = "Backward"
        Me.Backward.Size = New System.Drawing.Size(75, 23)
        Me.Backward.TabIndex = 1
        Me.Backward.Text = "Backward"
        Me.Backward.UseVisualStyleBackColor = True
        '
        'Forward
        '
        Me.Forward.Location = New System.Drawing.Point(93, 9)
        Me.Forward.Name = "Forward"
        Me.Forward.Size = New System.Drawing.Size(75, 23)
        Me.Forward.TabIndex = 2
        Me.Forward.Text = "Forward"
        Me.Forward.UseVisualStyleBackColor = True
        '
        'Reload
        '
        Me.Reload.Location = New System.Drawing.Point(263, 9)
        Me.Reload.Name = "Reload"
        Me.Reload.Size = New System.Drawing.Size(75, 23)
        Me.Reload.TabIndex = 3
        Me.Reload.Text = "Refresh"
        Me.Reload.UseVisualStyleBackColor = True
        '
        'Search
        '
        Me.Search.Location = New System.Drawing.Point(344, 9)
        Me.Search.Name = "Search"
        Me.Search.Size = New System.Drawing.Size(75, 23)
        Me.Search.TabIndex = 4
        Me.Search.Text = "Search"
        Me.Search.UseVisualStyleBackColor = True
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"www.google.com", "www.bing.com", "www.youtube.com", "www.github.com", "www.github.com/Miky81/VBB-BrowserGO"})
        Me.ComboBox1.Location = New System.Drawing.Point(425, 9)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(768, 21)
        Me.ComboBox1.TabIndex = 5
        '
        'WebBrowser1
        '
        Me.WebBrowser1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.WebBrowser1.Location = New System.Drawing.Point(0, 50)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.Size = New System.Drawing.Size(1263, 654)
        Me.WebBrowser1.TabIndex = 7
        Me.WebBrowser1.Url = New System.Uri("http://google.com", System.UriKind.Absolute)
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(1200, 8)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(63, 23)
        Me.Button1.TabIndex = 8
        Me.Button1.Text = "About"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1265, 706)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.WebBrowser1)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Search)
        Me.Controls.Add(Me.Reload)
        Me.Controls.Add(Me.Forward)
        Me.Controls.Add(Me.Backward)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "VBB GO"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Backward As Button
    Friend WithEvents Forward As Button
    Friend WithEvents Reload As Button
    Friend WithEvents Search As Button
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents WebBrowser1 As WebBrowser
    Friend WithEvents Button1 As Button
End Class

﻿Public Class Form1
    Private Sub WebBrowser1_DocumentCompleted(sender As Object, e As WebBrowserDocumentCompletedEventArgs)

    End Sub

    Private Sub Backward_Click(sender As Object, e As EventArgs) Handles Backward.Click
        WebBrowser1.GoBack()
    End Sub

    Private Sub Forward_Click(sender As Object, e As EventArgs) Handles Forward.Click
        WebBrowser1.GoForward()
    End Sub

    Private Sub Reload_Click(sender As Object, e As EventArgs) Handles Reload.Click
        WebBrowser1.Refresh()
    End Sub

    Private Sub Search_Click(sender As Object, e As EventArgs) Handles Search.Click
        WebBrowser1.Navigate(ComboBox1.Text)
    End Sub

    Private Sub WebBrowser1_DocumentCompleted_1(sender As Object, e As WebBrowserDocumentCompletedEventArgs) Handles WebBrowser1.DocumentCompleted

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        About.Show()
    End Sub
End Class
